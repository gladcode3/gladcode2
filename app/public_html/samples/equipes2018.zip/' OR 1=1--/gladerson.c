#include <stdlib.h>
#include <time.h>
#include <math.h>

#define RAD2GRAD 57.2958f
#define GRAD2RAD 0.0174533f

#define CENTRO_ARENA 12.5f
#define FATOR_SEGURANCA 0.75f

#define DISTANCIA_INIMIGO_FODEU 5.f

setup(){
    setName("Gladerson DoItAll");
    setSTR(3);
    setAGI(8);
    setINT(5);
    setSpritesheet("2286bfcccd4f2fe6fe200f6957d5df0b");
    upgradeSTR();
}

float getRandomSafePosition() {
    srand(time(NULL));

    return (CENTRO_ARENA - getSafeRadius()) + fmod(rand(), getSafeRadius() * 2.f);
}

int taDentro() {
    return getDist(CENTRO_ARENA, CENTRO_ARENA) <= getSafeRadius();
}

int antiHorario = 0, acabouDeTrocarSentido = 0, movendoCentro = 0;

loop(){
    if (movendoCentro) {
        moveTo(CENTRO_ARENA, CENTRO_ARENA);

        if (!moveTo(CENTRO_ARENA, CENTRO_ARENA) || getDist(CENTRO_ARENA, CENTRO_ARENA) <= 0.f)
            movendoCentro = 0;
    }
    else if (!getCloseEnemy()) {
        turnTo(CENTRO_ARENA, CENTRO_ARENA);
        stepRight();

        if (getDist(CENTRO_ARENA, CENTRO_ARENA) >= getSafeRadius() * FATOR_SEGURANCA)
            stepForward();
        if (getHit()) {
            teleport(getRandomSafePosition(), getRandomSafePosition());
            turnToAngle(getLastHitAngle());
        }
        antiHorario = 0;
        acabouDeTrocarSentido = 0;
        movendoCentro = 0;
    }
    else {
        turnToTarget();
        while (getDist(getTargetX(), getTargetY()) > DISTANCIA_INIMIGO_FODEU && taDentro()) {
            if (getHit()) {
                float anguloX = cosf(getLastHitAngle()), anguloY = sinf(getLastHitAngle());

                teleport(getTargetX() + anguloX * DISTANCIA_INIMIGO_FODEU, getTargetY() + anguloY * DISTANCIA_INIMIGO_FODEU);
                continue;
            }
            
            moveToTarget();
        }
        while (getDist(getTargetX(), getTargetY()) < DISTANCIA_INIMIGO_FODEU && taDentro()) {
            if (getHit()) {
                float anguloX = cosf(getLastHitAngle()), anguloY = sinf(getLastHitAngle());

                teleport(getTargetX() + anguloX * DISTANCIA_INIMIGO_FODEU, getTargetY() + anguloY * DISTANCIA_INIMIGO_FODEU);
                continue;
            }
            stepBack();
        }            
        if (antiHorario)
            stepLeft();
        else
            stepRight();
        
        if (getAmbushTimeLeft() == 0.f)
            ambush();
        if (getAp() >= 30.f)
            assassinate();
        else
            attackRanged(getTargetX(), getTargetY());

        if (!isSafeHere() || getDist(CENTRO_ARENA, CENTRO_ARENA) >= 11.5f) {
            antiHorario = !antiHorario;

            if (acabouDeTrocarSentido) {
                if (getAp() >= 40.f)
                    teleport(getRandomSafePosition(), getRandomSafePosition());                
                else {
                    moveTo(CENTRO_ARENA, CENTRO_ARENA); 
                    movendoCentro = 1;
                }
            }
            acabouDeTrocarSentido = 1;
        }
        else
            acabouDeTrocarSentido = 0;
    }
}

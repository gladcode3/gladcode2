setup(){
    setName("Guilhrm Javeirus");
    setSTR(10);
    setAGI(1);
    setINT(2);
    setSpritesheet("3558919decebcc79a23cc6feb74667fe");
    upgradeSTR();
}

int charger = 0, start = 1;

loop(){
	if (getCloseEnemy()) {
		float dist = getDist(getTargetX(), getTargetY());
		if (getBlockTimeLeft() < 0.6)
			block();
			
		if (dist < 0.8 && isTargetVisible()) {
			attackMelee();
		}
		else {
			if(getAp() > 30) {
				charge();
			}
			else
				moveTo(getTargetX(), getTargetY());
		}
	}
	else {
		if (start) {
			if(moveTo(12.5,12.5))
				start = 0;
		}
		else
			turnLeft(50);
	}
	
	if (!isSafeHere())
		teleport(12.5,12.5);
	
	if (getSTR() == 20)
		upgradeAGI();
}

#define ARENA_MEIO 12.5

setup(){
    setName("batatinha");
    setSTR(8);
    setAGI(5);
    setINT(3);
    setSpritesheet("125dca932dd1ab51bc6bb815bfa425ae");
    upgradeSTR();
}

int start = 1;
float hp;

loop(){	
	//if (upgradeINT() <= 5){
	//	upgradeINT();
	//}
	//else{
	//	upgradeSTR();
	//}

	float range = getDist(getTargetX(), getTargetY());                          
	int hit = 1;

	if (hp != getHp()){
		hp = getHp();
		hit = 1;
	}

	if (hit){
		//if (getBlockTimeLeft() < 1.5)// tem q trocar
			//block();
	while(!turnToAngle(getLastHitAngle()));
	}
	
	if (getLowHp() && getCloseEnemy()){

		while(moveTo(getTargetX(), getTargetY()));
		if (isTargetVisible() && getAp() < 90 && range <= 0.8){
			attackMelee();
		}
		else if (isTargetVisible() && getAp() >= 90){
			charge();
		}
	else if (!start){
		turn(50);
	}
	else if (start){
		if(moveTo(12.5,12.5))
			start = 0;
	}
	}
}
	


setup(){
    setName("Razor");
    setSTR(9);
    setAGI(5);
    setINT(0);
    setSpritesheet("6966dd4d0eda6c76ce8b322cb6564c85");
    upgradeAGI();
}
int f = 0;
float r = 1;

loop(){
	if (!getCloseEnemy()){
		if (f)
			turnRight(100);
			
		else if (moveTo(12.5,5.0))
			f = 1;
	}
	else{
	
		attackRanged(getTargetX(), getTargetY());
	}
	while (getDist(12.5,12.5) >= getSafeRadius() - 2)
		moveTo(12.5,12.5);
	
	
		
}

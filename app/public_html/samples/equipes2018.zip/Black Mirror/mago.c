setup(){
    setName("Mago");
    setSTR(5);
    setAGI(0);
    setINT(9);
    setSpritesheet("62f163c2608897a44e9fc0d8e310e1b1");
    upgradeSTR();
}
int f = 1;

	loop(){
		if(f){		
		teleport(18.5,20.0);
		f = 0;
	}

	if(getCloseEnemy()){
		if (getAp() >= 40)
			fireball(getTargetX(), getTargetY());
		else
			attackRanged(getTargetX(), getTargetY());
	}
	else{
		
		turnRight(80);
	}
	while (getDist(12.5,12.5) >= getSafeRadius() - 2)
		moveTo(12.5,12.5);

}


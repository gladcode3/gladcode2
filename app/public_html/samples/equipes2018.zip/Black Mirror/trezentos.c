setup(){
    setName("trezentos");
    setSTR(10);
    setAGI(3);
    setINT(0);
	setSpritesheet("b4f539a01e539c458bba6adb215af272");
	upgradeSTR();
}

int f = 1;

loop(){
	if (getCloseEnemy()){
		float dist = getDist(getTargetX(), getTargetY());
		if (dist < 0.7 && isTargetVisible()){
			attackMelee();
		}
		else
			moveTo(getTargetX(), getTargetY());
	}
	else{
		if (f){
			if(moveTo(12.5,12.5))
				f = 0;
		}
		else
			turnRight(50);
	}
	while (getDist(12.5,12.5) >= getSafeRadius() - 2)
		moveTo(12.5,12.5);
	
}

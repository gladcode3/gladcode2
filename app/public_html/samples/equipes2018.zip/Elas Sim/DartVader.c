setup(){
    setName("DarthVader");
    setSTR(5);
    setAGI(6);
    setINT(6);
    setSpritesheet("b5bd3f6b8f4472f24658c68836f4d4f3");
}

loop(){
	if(getLowHp()){
		if (getAp() >= 40)
			fireball(getTargetX(), getTargetY());
		else
			attackRanged(getTargetX(), getTargetY());
	}
	else{
		while(getX() != 17.1 || getY() != 17.1)
			teleport(11.5,12.5);
		turn(50);
	}

}
	

setup(){
    setName("LeiaOrgana");
    setSTR(6);
    setAGI(6);
    setINT(5);
    setSpritesheet("6d4d12b67360d210b7ff161af83176a3");
}

int start = 1;

loop(){
	if (start){
		if(moveTo(11.4,11.4))
			start = 0;
	}
	
	if (getLowHp()){
		if(doYouSeeMe()){
			if (getAmbushTimeLeft() <= 2){
				ambush();
			}
			else{
				turnTo(getTargetX(), getTargetY());
				stepLeft();
			}
		}
		else{
			if (getAmbushTimeLeft() >2){
				attackRanged(getTargetX(), getTargetY());
				assassinate();
			}
			else{
				ambush();
			}
		}
		
	}
	else if (!start)
		turn(51);
}

setup(){
    setName("LukeSkywalker");
    setSTR(7);
    setAGI(1);
    setINT(7);
    setSpritesheet("1d7345611221736d472a2ab6ff120f4e");
}

int start = 1;
float hp;

loop(){
	int hit = 0;
	if (hp != getHp()){
		hp = getHp();
		hit = 1;
	}

	if (hit){
		if (getBlockTimeLeft() < 1.5)
			block();
		while(!turnToAngle(getLastHitAngle()));
	}

	if (getHighHp()){
		charge();
	}
	else if (!start)
		turn(50);
	else if (start){
		if(moveTo(10.8,10.8))
			start = 0;
	}
}
	

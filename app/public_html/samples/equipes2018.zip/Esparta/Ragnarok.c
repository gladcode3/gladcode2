setup(){
    setName("Ragnarok");
    setSTR(6);
    setAGI(6);
    setINT(5);
    setSpritesheet("7cd72d5ef9df03368ec3cdbeee1f3b4c");
	upgradeSTR();
}

int start = 1;

loop(){
	if (getCloseEnemy()){
		float dist = getDist(getTargetX(), getTargetY());
		if (dist < 11.0 ){
		attackRanged(getTargetX(), getTargetY());
		}
		
	}	
	else{
		while(getX() != 12.5 || getY() != 12.5)
			teleport(12.5,12.5);
		turn(50);

	}
}
	
	
	
	
	
	
	
	
	
	
	
	















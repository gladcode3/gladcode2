setup(){
    setName("Galahad");
    setSTR(8);
    setAGI(5);
    setINT(3);
    setSpritesheet("7537b889c99e75c73baf576a3a827566");
    upgradeAGI();
}
loop(){
	if (getHp()<140){
		block();
	}
	if (getCloseEnemy()){
		if (getAp()>40){
			fireball(getTargetX(),getTargetY());
		}
		else {
			attackMelee();	
		}
	}
	else{
		if(getX()!=12.5 || getY()!=12.5)
			teleport(12.5,12.5);
	}
}

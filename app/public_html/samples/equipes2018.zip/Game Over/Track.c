setup(){
    setName("Track");
    setSTR(9);
    setAGI(4);
    setINT(2);
    setSpritesheet("fe1f3363feb4eafa998c50b19f4ad549");
    upgradeAGI();
}
loop(){
	if (getHp()<140){
		block();
	}
	if (getCloseEnemy()){
		if (getAp()>40){
			fireball(getTargetX(),getTargetY());
		}
		else {
			attackMelee();	
		}
	}
	else{
		if(getX()!=12.5 || getY()!=12.5)
			teleport(12.5,12.5);
	}
}

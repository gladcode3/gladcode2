setup(){
    setName("Artemis");
    setSTR(5);
    setAGI(6);
    setINT(6);
    setSpritesheet("09a8c33b0e2c9ca57ce3110226894ecc");
    upgradeSTR();
}
loop(){
	if (getHp()<100){
		block();
	}
	if (getCloseEnemy()){
			charge();
		if (getAp()>40){
			fireball(getTargetX(),getTargetY());
		}
		else {
			attackMelee();	
		}
	}
	else{
		if(getX()!=12.5 || getY()!=12.5)
			teleport(12.5,12.5);
	}
}

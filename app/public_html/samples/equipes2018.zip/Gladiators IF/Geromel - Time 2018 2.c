setup(){
    setName("Geromel");
    setSTR(10);
    setAGI(3);
    setINT(0);
    setSpritesheet("14e68534a371041dff0a2d522e56eaac");
}
int start = 1;

loop(){
	if (getSTR() >= 16)
        upgradeAGI();
    else
        upgradeSTR();
       
	    if(getFarEnemy()){
		if (getAp() >= 40)
			fireball(getTargetX(), getTargetY());
		else
			attackRanged(getTargetX(), getTargetY());
	}
	else{
		while(getX() != 12.5 || getY() != 12.5)
			teleport(12.5,12.5);
		turn(50);
		
	if(getFarEnemy ()){
		if (doYouSeeMe() && getBlockTimeLeft() <= 0)
	block();
			else if (getAp() >= 40)
		fireball(getTargetX(), getTargetY());
		
		else
			attackRanged(getTargetX(), getTargetY());
}
	}

    if (getCloseEnemy ()){
        if (getHp() > 20)
            while(!attackRanged(getTargetX(), getTargetY()));
        else
            stepBack();
    }
    else
        turnRight(5);
}




	

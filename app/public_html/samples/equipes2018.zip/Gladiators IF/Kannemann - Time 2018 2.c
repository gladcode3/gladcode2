setup(){
    setName("Kannemann");
    setSTR(3);
    setAGI(8);
    setINT(5);
    setSpritesheet("21ecf4944d9eca15b67138be0215dfb6");
}
float r = 1;


loop(){
	if (getAGI() >= 15)
        upgradeINT();
    else
        upgradeAGI();
                while(isSafeHere() && !moveTo(r,r));
	while(isSafeHere() && !moveTo(25-r,r));
	while(isSafeHere() && !moveTo(25-r,25-r));
	while(isSafeHere() && !moveTo(r,25-r));
	while (getDist(12.5,12.5) >= getSafeRadius() - 2)
		moveTo(12.5,12.5);
	r = 12.5 - getSafeRadius()/2;
	
	 if (getCloseEnemy ()){
        if (getHp() > 20)
            while(!attackRanged(getTargetX(), getTargetY()));
        else
            	fireball(getTargetX(), getTargetY());
    }
    else
        turnRight(5);
        if(isSafeHere ()){
		if (getAp() >= 40)
			fireball(getTargetX(), getTargetY());
		else
			attackRanged(getTargetX(), getTargetY());
	}
	else{
		while(getX() != 12.5 || getY() != 12.5)
			teleport(12.5,12.5);
		turn(50);
        
    }
}

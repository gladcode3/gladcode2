setup(){
    setName("Zeus");
    setSTR(8);
    setAGI(4);
    setINT(4);
    setSpritesheet("38a93c76d66eb52526ab9ef43f2a6131");
}
int start = 1;
float r = 1;
loop(){if (getSTR() >= 15)
        upgradeAGI();
    else
        upgradeSTR();
         if (getCloseEnemy ()){
        if (getSpeed() > getTargetSpeed()){
            if(getDist(getTargetX(), getTargetY()) <= 1)
                attackMelee();
            else
                moveToTarget();
        }
        else
            attackRanged(getTargetX(), getTargetY());
    }
    else
        turnLeft(5);
	
	
	
if(getLowHp()){
		if (getAp() >= 40)
			fireball(getTargetX(), getTargetY());
		else
			attackRanged(getTargetX(), getTargetY());
	}
	else{
		while(getX() != 12.5 || getY() != 12.5)
			teleport(12.5,12.5);
		turn(50);
}
}

setup(){
    setName("Arqueiro");
    setSTR(5);
    setAGI(9);
    setINT(0);
    setSpritesheet("34ec8db516eacb0b187966d91d03f39f");
	upgradeAGI();
}


loop(){

	if(getLowHp()){
		attackRanged(getTargetX(),getTargetY());
	}
	
	else{
		moveTo(12.5,12.5);
	}

}

	

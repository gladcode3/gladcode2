setup(){
    setName("Lutador j");
    setSTR(9);
    setAGI(5);
    setINT(0);
    setSpritesheet("6a9d74e3f53a26b6006e1a7605c8d9bf");
	upgradeSTR();
}
	int f=1;
loop(){

	if(f==1){
		if(moveTo(12.5,12.5)){
			f=0;
		}
	}

	if (getFarEnemy()){

		float d = getDist(getTargetX(), getTargetY());
		
			if (d < 0.8){
				attackMelee();
			}
			else if(d > 0.8){
				charge();
			}
			
		}

	else if(getHit()){
			while(!turnToAngle(getLastHitAngle())){
				if(getCloseEnemy()){
					break;
				}
			}
		}

	else{
		moveTo(12.5,12.5);
	}
}


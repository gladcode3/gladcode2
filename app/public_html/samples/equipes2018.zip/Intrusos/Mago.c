setup(){
    setName("Mago");
    setSTR(2);
    setAGI(4);
    setINT(9);
    setSpritesheet("9a546eb3bcfcd4e1e8b24047d38cbd1b");
	upgradeINT();
}
int f=1;

float tY,tX;

	void tp(){
		teleport(tX,tY);
	}
	
loop(){
	
	float d = getDist(getTargetX(), getTargetY());
	
	tY= getTargetY();
	tX= getTargetX();
	
	if(f==1){
		if(moveTo(12.5,12.5)){
			f=0;
		}
	}
	
	if (d < 2){
		if(tY<=17 || tX<=17){	
			tY=tY+7.0;
			tX=tX+7.0;
			tp();
	}
		else if(tY>=8 || tX>=8){	
			tY=tY-7.0;
			tX=tX-7.0;
			tp();
			}
}

	else if(getLowHp()){
		if(getAp()>=40){
			fireball(getTargetX(),getTargetY());
		}else{
			attackRanged(getTargetX(),getTargetY());
		}
		
	}

	else{
		moveTo(12.5,12.5);
	}

}

	

setup(){
    setName("JIREN");
    setSTR(5);
    setAGI(6);
    setINT(6);
    setSpritesheet("6ac87525817852476b0dfc815d142bda");
}


float r = 1;

void fogeDoGas() {
    int xg,yg; //função para fugir do gás
	while(isSafeHere() && !moveTo(r,r)){
        if(howManyEnemies() != 0){
            getCloseEnemy();
            xg=getTargetX();
            yg=getTargetY();
            if(getDist(xg,yg) <=1){
                break;
            }
        }  
    }
    while(isSafeHere() && !moveTo(25-r,r)){
        if(howManyEnemies() != 0){
            getCloseEnemy();
            xg=getTargetX();
            yg=getTargetY();
            if(getDist(xg,yg) <=1){
                break;
            }
        }  
    }
    while(isSafeHere() && !moveTo(25-r,25-r)){
        if(howManyEnemies() != 0){
            getCloseEnemy();
            xg=getTargetX();
            yg=getTargetY();
            if(getDist(xg,yg) <=1){
                break;
            }
        }  
    }
    while(isSafeHere() && !moveTo(r,25-r)){
        if(howManyEnemies() != 0){
            getCloseEnemy();
            xg=getTargetX();
            yg=getTargetY();
            if(getDist(xg,yg) <=1){
                break;
            }
        }  
    }
    while (getDist(12.5,12.5) >= getSafeRadius() - 2){
        if(howManyEnemies() != 0){
            getCloseEnemy();
            xg=getTargetX();
            yg=getTargetY();
            if(getDist(xg,yg) <=1){
                break;
            }
        }  
        moveTo(12.5,12.5);
    }
	r = 12.5 - getSafeRadius()/2;
	
	
}

int passo1 = 1;

void primeiroMovimento() //manda o gladiador para borda na primeira jogada
{
	if(getX()>=10 && getY()>=10)
	{
		teleport(25,25);
	}
	else
	{
		if(getX()<=15 && getY()<=15)
		{
			teleport(0,0);
		}
		else
		{
			if(getX()>=10 && getY()<=15)
			{
				teleport(25,0);
			}
			else
			{
				if(getX()<=15 && getY()>=10)
				{
					teleport(0,25);
				}
			}
		}
	}		
}

void ganhouUpou(){
	if(getINT()<10){
        upgradeINT();
    }
    else{
        upgradeAGI();
    }
    
}

void eSeguroAqui(){
	if(isSafeHere()==0){
		fogeDoGas();
	}
}


loop(){
    float x,y;
    ganhouUpou();
    eSeguroAqui();
    if(passo1 == 1){
		primeiroMovimento();
		passo1++;
	}
    if(howManyEnemies() != 0){
        getCloseEnemy();
        x=getTargetX();
        y=getTargetY();
        if (!doYouSeeMe()){
            if(getAp()>=40 && getDist(x,y) >2){
                fireball(x,y);
            }
            else{
                if(getAp()>=30){
                    charge();
                }
                else {
                    attackRanged(x,y);
                }
            }
        }
        else {
            if(getAp()>=60){
                if(getAmbushTimeLeft()<=0){
                    ambush();    
                }
                if(getAp()>=30){
                    assassinate();
                }
                else{
                    attackRanged(x,y);
                }
            }
            else{
                if(getAp()>=40 && getDist(x,y) >2){
                    fireball(x,y);
                }
                else{
                    if(getAp()>=30){
                        charge();
                    }
                    else {
                        attackRanged(x,y);
                    }
                }
            }
        }
    }
    else{
        turn(60);
    }  
}
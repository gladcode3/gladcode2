#include<math.h>
setup(){
    setName("Annajujuneko");
    setSTR(6);
    setAGI(6);
    setINT(5);
    setSpritesheet("3ea14a73b9a1193529f28145f92ee684");
}

loop(){
   if (getSTR() >= 20){
        upgradeINT();
    }
	else if(getINT() >= 20){
    	upgradeSTR();
	}
	else{
    	upgradeAGI();
	}
	
    int start = 1;    
	if (start){
		if(moveTo(12.0,12.0)){
			start = 0;
		}
	}
	 if (!isSafeHere()){
		moveTo(12.5,12.5);
	}
	if (getHit()){
    	turnToAngle(getLastHitAngle());
            if (getCloseEnemy()){
            	float dist = getDist(getTargetX(), getTargetY());
            		if (dist < 0.3 && isTargetVisible()){
            			attackMelee();
            			moveTo(getTargetX(), getTargetY());   
					}
					if(getAp() >= 80 && isTargetVisible()){ 
        				fireball(getTargetX(), getTargetY());
						charge();
					}
				}
    }
		   
		if (getCloseEnemy()){
			float dist = getDist(getTargetX(), getTargetY());
			if (dist < 0.8 && isTargetVisible()){
				attackMelee();
				if (getAp() >= 30){
					assassinate();
				}
			}
		}
		 if (howManyEnemies() < 3 ){
		 	if(getX() + 8.0 != 25.0 && getY() + 8.0 != 25.0  && getX() - 8.0 != 0.0 && getY() - 8.0 != 0.0){
		 		if(getAp()>=100){
				 	teleport(getTargetX() + 4.0, getTargetY() + 6.0);
				 }
			 }
			 else{
			 	if(getAp()>=100){
			 		teleport(getTargetX() - 5.0, getTargetY() - 5.0);
				}
			}		
			attackRanged(getTargetX(), getTargetY());
		}
   		 else if (howManyEnemies() < 1 ){
    		getLowHp();
			moveTo(getTargetX(), getTargetY());   
				 if (getAp() >= 30){
					assassinate();
        		}
		}
	
	if (isSafeHere()){
		if(isTargetVisible() && getLowHp()){
			 if (getCloseEnemy()){
				attackRanged(getTargetX(), getTargetY());
				moveTo(getTargetX(), getTargetY());
			}
			if(getAp() >= 50){ 
				block();
			}
		}
			else if(getLowHp()){ 
				moveTo(getTargetX(), getTargetY());
				attackRanged(getTargetX(), getTargetY());
				if(getAp() >= 40){ 
					fireball(getTargetX(), getTargetY());
				}
			}
	}
 	if(!isTargetVisible()){
 		moveTo(12.5,12.5);
 	}
}


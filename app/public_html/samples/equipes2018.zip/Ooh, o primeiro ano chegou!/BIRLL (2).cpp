setup(){
    setName("BIRLL");
    setSTR(8);
    setAGI(4);
    setINT(4);
    setSpritesheet("50efc3f272902cddc3cabd5350ae6657");
    
    if (getSTR() >= 12){
        upgradeAGI();
    }
	else if(getAGI() >= 10){
    	upgradeINT();
	}
	else{
    	upgradeSTR();
	}
}

int start = 1;

loop(){
	if (start){
		if(moveTo(11.5,11.5))
			start = 0;
	}
	
	if(getCloseEnemy()){
		if (getDist(getTargetX(), getTargetY()) < 0.8 && isTargetVisible()){
			if(getAp() >= 50){
				block();	
			}
			attackMelee();
		}
		else{
			if(getAp() >= 30){
				charge();
			}
			moveTo(getTargetX(), getTargetY());
		}
	}
	if((getLastHitTime() <= 3.0 || getHit) && isTargetVisible()){
		if(getTargetHealth() >= 7.0){
			if(getAp() >= 40){
				block();
			}
		}
	}
	if (getHit()){
		while(!turnToAngle(getLastHitAngle())){
			if (getCloseEnemy()){
				moveTo(getTargetX(), getTargetY());
				while(!attackRanged(getTargetX(), getTargetY()));
				//MODIFICADO
				// TESTAR E PERCEBER SE NECESSITA DE ELSE
				// VERIFICAR SE O WHILE TA PEGANDO DIREITO
			}
		}
    }
	else{
		if(getX() != 12.5 && getY() != 12.5){
			moveTo(12.5, 12.5);
		}
	}
	
	if(!isSafeHere()){
		moveTo(12.5, 12.5);
	}
}

setup(){
    setName("maga da equipe");
    setSTR(4);
    setAGI(4);
    setINT(8);
    setSpritesheet("ffc41a197a10593614ecf7e430b6ff69");
}

loop(){
  
	if(getINT() >= 20){
    	upgradeSTR();
	}
	else if (getSTR() >= 16){
        upgradeINT();
    }
	else{
    	upgradeAGI();
	}
	
    int start = 1;    
	if (start){
		if(moveTo(12.0,12.0)){
			start = 0;
			ambush();
		}
	}
	if(!isSafeHere()){
		moveTo(12.5,12.5);
	}
	if (getHit()){
        while(!turnToAngle(getLastHitAngle())){
            if (getCloseEnemy()){
            	moveTo(getTargetX(), getTargetY()); 
				attackMelee();  
				charge();
			}
			else {
				getLowHp();
				attackRanged(getTargetX(), getTargetY());
					if (getAp() >= 100){
						assassinate();
						ambush();
				}	
			}
        }
       
    }
		if (getCloseEnemy()){
		float dist = getDist(getTargetX(), getTargetY());
		if (dist < 0.8 && isTargetVisible()){
			attackMelee();
			if (getAp() >= 30){
				assassinate();
			}
		}
		else
			moveTo(getTargetX(), getTargetY());
	}
	if (howManyEnemies() == 1 ){
		    if (getAp() >= 30){
				assassinate();
			}
			else{
				attackMelee();
			}
        }

    else if (howManyEnemies() > 1 && getDist( getTargetX(), getTargetY()) > abs(3.0) ){
        attackRanged(getTargetX(), getTargetY());
		if(getAp() >=80){ 
        	fireball(getTargetX(), getTargetY());
			charge();
		}
    }
    if (howManyEnemies() < 3 ){		 
		fireball(getTargetX(), getTargetY());			 
		attackRanged(getTargetX(), getTargetY());
	}		
			
	
	if(getLowHp()){
		if (getAp() >= 40)
			fireball(getTargetX(), getTargetY());
		else
			attackRanged(getTargetX(), getTargetY());
	}
	 
}

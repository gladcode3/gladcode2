setup(){
    setName("Caveira Nerd");
    setSTR(5);
    setAGI(0);
    setINT(9);
    setSpritesheet("d6fac293cf866a9412ae3622ea3de92a");
}

int count_level=1;
int resto_level;
int teste=0;

loop(){
    //comportamento do gladiador
    if(getLowHp()){
		if (getAp() >= 40)
			fireball(getTargetX(), getTargetY());
		else
			attackRanged(getTargetX(), getTargetY());
	}
	else if(isSafeHere()){
		while(getX() != 17.5 || getY() != 14.5)
			teleport(17.5,14.5);
		turn(50);
		turn(50);
	}else
		while(getX() != 12.5 || getY() != 12.5)
			teleport(12.5,12.5);
	
	if (getSTR() >= 10)
        upgradeINT();
    else
        upgradeSTR();
}

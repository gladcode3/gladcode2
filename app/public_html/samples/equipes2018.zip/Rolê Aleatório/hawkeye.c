setup(){
    setName("Hawkeye");
    setSTR(5);
    setAGI(9);
    setINT(0);
    setSpritesheet("3200273ad7a2c116d1c1e23fbc0f3a5d");
}

int condicao = 1;

loop(){
    //comportamento do gladiador
    if (getLowHp()){
        if (getHp() > 20)
            while(!attackRanged(getTargetX(), getTargetY()));
        else
        	ambush();
            stepBack();
    }
    else{
        turn(180);
        if(isSafeHere() && condicao<=1){
        	while(getX() != 7.5 || getY() != 9.5)	
   				if (getAp() >= 50)
					teleport(7.5,9.5);
				else
					moveTo(7.5,9.5);
					ambush();
		}else{
			while(getX() != 12.5 || getY() != 12.5)
			moveTo(12.5,12.5);
			condicao=100;
		}
	}
    

    
	if (getSTR() >= 6)
        upgradeAGI();
    else
        upgradeSTR();
}

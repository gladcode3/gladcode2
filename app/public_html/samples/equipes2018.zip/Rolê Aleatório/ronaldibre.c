setup(){
    setName("Ronaldibre");
    setSTR(9);
    setAGI(5);
    setINT(0);
    setSpritesheet("0d1add0e00209ccf1b9666138486b2e5");
}

int booleana = 1;

loop(){
	//comportamento do gladiador
	if (getCloseEnemy()){
		float dist = getDist(getTargetX(), getTargetY());
		
		if (dist < 0.8 && isTargetVisible()){
			attackMelee();
		} else {
			moveTo(getTargetX(), getTargetY());
		}
	} else {
		if (booleana==1){
			while(getX() != 12.5 || getY() != 12.5){
				moveTo(12.5,12.5);
			}
			booleana = 0;
		}
		else turn(50);
	}
	
	if(!isSafeHere()){
	 	while(getX() != 12.5 || getY() != 12.5){
			moveTo(12.5,12.5);
		}
	}
	
	if (getSTR() >= 20)
        upgradeAGI();
    else
        upgradeSTR();
}

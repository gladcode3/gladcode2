
setup(){
    setName("ttcMASTER2000");
    setSTR(8);
    setAGI(3);
    setINT(5);
    setSpritesheet("30da90d5fd73a0cc10b95842665fed8d");
}

int xSafe=13;
int ySafe=13;
int relative=1;
int xGo=1;
int yGo=1;

void up () {
	if (getSTR() < 15) {
    	upgradeSTR();
	}else if (getAGI() < 15) {
		upgradeAGI();
	}else{
		upgradeINT();
	}
}

void tele() {
	if (getAp() >= 70) {
		if (getX() != 13 || getY() != 13) {
			teleport(13,13);	
		}
	}
}

void ataque() {
	if (getAp() >= 70) {
		fireball(getTargetX(),getTargetY());
		charge();
		tele();
	}else{
		if (getAp() >= 40) {
			fireball(getTargetX(),getTargetY());	
		}else{
			if (getAp() >= 30) {
				charge();
			}else{
				if(getDist(getTargetX(), getTargetY()) <= 1) {
					attackMelee();
				}else{
					attackRanged(getTargetX(), getTargetY());
					moveToTarget();
				}
			}
		}
	}
}

void identPosition() {
	if (getX() < 12.5 && getY() < 12.5) {
    	xGo = 1;
    	yGo = 1;
	}else if (getX() > 12.5 && getY() > 12.5) {
		xGo=24;
		yGo=24;		
	}else if (getX() < 12.5 && getY() > 12.5) {
		xGo=24;
		yGo=1;		
	}else if (getX() > 12.5 && getY() < 12.5) {
		xGo=1;
		yGo=24;		
	}
}

void action () {
	if (getSafeRadius() < 17.5) {
    	if ( (getX() > xSafe+relative || getX() < xSafe-relative) || (getY() > ySafe+relative || getY() < ySafe-relative) ) {
    		moveTo(xSafe, ySafe);	
		}
	}else{
		if ( (getX() > xGo+relative || getX() < xGo-relative) || (getY() > yGo+relative || getY() < yGo-relative) ) {
			moveTo(xGo,yGo);	
		}
	}
}

loop(){
    
    up();
    
	if (getCloseEnemy()) {
		ataque();
	}else{
		identPosition();
		action();
		turn(90);
	}
    
	    
    
}

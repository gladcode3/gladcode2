setup(){
    setName("sirius");
    setSTR(10);
    setAGI(2);
    setINT(1);
    setSpritesheet("17dd7f271bd438f7f7b4883044c8ee47");
}


int start = 1;

loop(){
	if (getCloseEnemy()){
		float dist = getDist(getTargetX(), getTargetY());
		if (dist < 0.8 && isTargetVisible()){
			attackMelee();
		}
		else
			moveTo(getTargetX(), getTargetY());
	}
	else{
		if (start){
			if(moveTo(12.5,12.5))
				start = 0;
		}
		else
			turnLeft(50);
	}
}

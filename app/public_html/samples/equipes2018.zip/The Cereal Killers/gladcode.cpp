setup(){
    setName("sirius2");
    setSTR(8);
    setAGI(5);
    setINT(3);
    setSpritesheet("67a8eff09d205ce9c04ef08fe40fafe1");
   upgradeSTR();
}

int start = 1;

loop(){
	if (getCloseEnemy()){
		float dist = getDist(getTargetX(), getTargetY());
		if (dist < 0.8 && isTargetVisible()){
			attackMelee();
		}
		else
			moveTo(getTargetX(), getTargetY());
	}
	else{
		if (start){
			if(moveTo(12.5,12.5))
				start = 0;
		}
		else
			turnLeft(50);
	}
	if (getLowHp()){
        if (getSpeed() > getTargetSpeed()){
            if(getDist(getTargetX(), getTargetY()) <= 1)
                attackMelee();
            else
                moveToTarget();
        }
        else
            attackRanged(getTargetX(), getTargetY());
    }
    else
        turnLeft(5);
}

setup(){
    setName("sirius3");
    setSTR(6);
    setAGI(6);
    setINT(5);
      setSpritesheet("48b197141db04f8772c78e42752788ed");
	upgradeAGI();
}
int start = 1;

loop(){
	if (start){
		if(moveTo(12.5,12.5))
			start = 0;
	}
	
	if (getLowHp()){
		if(doYouSeeMe()){
			if (getAmbushTimeLeft() <= 0){
				ambush();
			}
			else{
				turnTo(getTargetX(), getTargetY());
				stepLeft();
			}
		}
		else{
			if (getAmbushTimeLeft() > 0){
				attackRanged(getTargetX(), getTargetY());
				assassinate();
			}
			else{
				ambush();
			}
		}
		
	}
	else if (!start)
		turn(50);
}

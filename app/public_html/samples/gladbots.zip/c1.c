setup(){
    setName("Patient");
    setSTR(10);
    setAGI(3);
    setINT(0);
	setSpritesheet("3d7529b3775b783c95d5a59c3c6e5c4e");
	upgradeSTR();
}

int start = 1;

loop(){
	if (getCloseEnemy()){
		float dist = getDist(getTargetX(), getTargetY());
		if (dist < 0.8 && isTargetVisible()){
			attackMelee();
		}
		else
			moveTo(getTargetX(), getTargetY());
	}
	else{
		if (start){
			if(moveTo(12.5,12.5))
				start = 0;
		}
		else
			turnLeft(50);
	}
}
setup(){
    setName("Arch");
    setSTR(5);
    setAGI(9);
    setINT(0);
    setSpritesheet("bc1883eae4622b6b55a2f30cd355472c");
	upgradeAGI();
}

int f = 0;

loop(){
	if (!getCloseEnemy()){
		if (f)
			turnRight(100);
		else if (moveTo(12.5,12.5))
			f = 1;
	}
	else
		attackRanged(getTargetX(), getTargetY());
}
setup(){
    setName("Runner");
    setSTR(6);
    setAGI(8);
    setINT(1);
    setSpritesheet("cf75c5e91a36feb5c7e78579fe4be9c1");
	upgradeINT();
}

loop(){
	if (getHit()){
		while(!turnToAngle(getLastHitAngle()));
		while (howManyEnemies() > 0)
			stepBack();
	}
	else{
		while (!isSafeHere() && !getHit()){
			moveTo(12,12);
		}
		while (!getHit() && isSafeHere() && !moveTo(20,5));
		while (!getHit() && isSafeHere() && !moveTo(5,20));
	}
	
}
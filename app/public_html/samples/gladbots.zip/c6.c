setup(){
	setName("Warrior");
	setSTR(10);
	setAGI(2);
	setINT(1);
    setSpritesheet("143e838426b59f835a4a4a360797b060");
	upgradeSTR();
}

int start = 1;
float hp;

loop(){
	int hit = 0;
	if (hp != getHp()){
		hp = getHp();
		hit = 1;
	}

	if (hit){
		if (getBlockTimeLeft() < 1.5)
			block();
		while(!turnToAngle(getLastHitAngle()));
	}

	if (getHighHp()){
		charge();
	}
	else if (!start)
		turn(50);
	else if (start){
		if(moveTo(12.5,12.5))
			start = 0;
	}
}
	
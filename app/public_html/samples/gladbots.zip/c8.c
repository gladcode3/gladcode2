setup(){
	setName("Blinker");
	setSTR(3);
	setAGI(0);
	setINT(10);
    setSpritesheet("360e4836c5fed2df98c7e5963374fdf6");
	upgradeINT();
}

float x = 5, y = 5;

void vai(){
	while(getX() != x || getY() != y)
		teleport(x,y);
}

loop(){
	vai();
	x = 20;
	vai();
	y = 20;
	vai();
	x = 5;
	vai();
	y = 5;
}
	